#!/usr/bin/env bash
set -e
USER="$1"; REPO="$2"
if [ -z "$USER" ] || [ -z "$REPO" ]; then
  echo "Uso: ./scripts/deploy_with_git.sh <github_user> <repo_name>"
  exit 1
fi
if [ ! -d ".git" ]; then
  git init
  git branch -m main || true
  git add .
  git commit -m "Versión inicial del sitio"
  git remote add origin "https://github.com/$USER/$REPO.git"
fi
git add .
git commit -m "Actualización de sitio" || true
git push -u origin main
echo "Ahora en GitHub: Settings → Pages → Deploy from a branch (main / root)."

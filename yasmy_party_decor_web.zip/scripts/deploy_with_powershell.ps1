param([Parameter(Mandatory=$true)][string]$User,[Parameter(Mandatory=$true)][string]$Repo)
if (!(Test-Path ".git")) {
  git init
  git branch -m main 2>$null
  git add .
  git commit -m "Versión inicial del sitio"
  git remote add origin "https://github.com/$User/$Repo.git"
}
git add .
git commit -m "Actualización de sitio" 2>$null
git push -u origin main
Write-Host "Ahora en GitHub: Settings → Pages → Deploy from a branch (main / root)."

#!/usr/bin/env python3
"""
Usage:
  python scripts/set_github_user.py <github_user> [repo_name]

- Reemplaza "TU_USUARIO" y "yasmy-party-decor-web" en README_GitHub.md y README.md
- Imprime la URL final de GitHub Pages
"""
import sys, os, re

if len(sys.argv) < 2:
    print("Uso: python scripts/set_github_user.py <github_user> [repo_name]")
    sys.exit(1)

user = sys.argv[1].strip()
repo = sys.argv[2].strip() if len(sys.argv) > 2 else "yasmy-party-decor-web"

root = os.path.dirname(os.path.abspath(__file__))
root = os.path.dirname(root)  # go to project root

files = ["README_GitHub.md", "README.md"]
replacements = {
    r"https://TU_USUARIO.github.io/yasmy-party-decor-web/": f"https://{user}.github.io/{repo}/",
    r"TU_USUARIO": user,
    r"yasmy-party-decor-web": repo
}

for fname in files:
    path = os.path.join(root, fname)
    if not os.path.exists(path): 
        continue
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    for pattern, repl in replacements.items():
        content = re.sub(pattern, repl, content)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

print("Actualizado.")
print("URL GitHub Pages:", f"https://{user}.github.io/{repo}/")
